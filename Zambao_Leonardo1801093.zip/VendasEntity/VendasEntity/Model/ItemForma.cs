﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.Model
{
    [Table("ItensForma")]
    class ItemForma
    {
        public ItemForma()
        {
            Venda = new Venda();
        }
        [Key]
        public int ItemFormaID { get; set; }
        public double Valor { get; set; }
        public Venda Venda { get; set; }
    }
}
