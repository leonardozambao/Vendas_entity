﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.Model
{
    class Context : DbContext
    {
        public Context() : base("DbCadastroVendas") { } //renomear o banco 
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Venda> Vendas { get; set; }
        public DbSet<Vendedor> Vendedores { get; set; }
        public DbSet<ItemVenda> ItensVenda { get; set; }
        // console
        // install-package EntityFramework
        // uninstall-package EntityFramework
        // enable-migrations | just once
        // add-migration
        // update-database -verbose
        // add-migration CriarEstado; update-database -verbose

    }
}
