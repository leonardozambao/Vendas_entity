﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Model;

namespace VendasEntity.Database
{
    class VendedorDAO
    {
        private static Context ctx = SingletonContext.GetInstance();
        public static void Cadastrar (Vendedor v)
        {
            ctx.Vendedores.Add(v);
            ctx.SaveChanges();
        }
        public static List<Vendedor> RetornarTodos()
        {
            // retorna todos os dados para uma lista
            return ctx.Vendedores.ToList();
        }
        public static Vendedor BuscaPorCpf(Vendedor v)
        {
            //retorna o primeiro valor encontrado
            return ctx.Vendedores.FirstOrDefault(x => x.Cpf.Equals(v.Cpf));
        }
    }
}
