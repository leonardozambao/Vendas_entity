namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class second : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.FormasDePagamento", "Venda_VendaID", c => c.Int());
            CreateIndex("dbo.FormasDePagamento", "Venda_VendaID");
            AddForeignKey("dbo.FormasDePagamento", "Venda_VendaID", "dbo.Vendas", "VendaID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.FormasDePagamento", "Venda_VendaID", "dbo.Vendas");
            DropIndex("dbo.FormasDePagamento", new[] { "Venda_VendaID" });
            DropColumn("dbo.FormasDePagamento", "Venda_VendaID");
        }
    }
}
