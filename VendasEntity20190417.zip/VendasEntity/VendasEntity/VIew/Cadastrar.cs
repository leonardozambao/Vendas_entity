﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;
using VendasEntity.Util;

namespace VendasEntity.VIew
{
    class Cadastrar
    {
        private static Context ctx = SingletonContext.GetInstance();
        public static void CadastrarCliente()
        {
            Cliente c = new Cliente();
            Cliente existe = new Cliente();
            Console.WriteLine("Informe o nome: ");
            c.Nome = Console.ReadLine();
            Console.WriteLine("informe o CPF:");
            c.Cpf = Console.ReadLine();
            existe = ClienteDAO.BuscaPorCpf(c);
            if (ValidaCpf.Valida(c.Cpf))
            {
                if (existe == null)
                {
                    ClienteDAO.Cadastrar(c);
                    Console.WriteLine("Cliente cadastrado!");
                }
                else Console.WriteLine("CPF já está cadastrado!");
            }
            else Console.WriteLine("CPF Inválido!");
        }
        public static void CadastrarVendedor()
        {
            Vendedor v = new Vendedor();
            Vendedor existe = new Vendedor();
            Console.WriteLine("Informe o nome: ");
            v.Nome = Console.ReadLine();
            Console.WriteLine("informe o CPF:");
            v.Cpf = Console.ReadLine();
            existe = VendedorDAO.BuscaPorCpf(v);
            if (ValidaCpf.Valida(v.Cpf))
            {
                if (existe == null)
                {
                    VendedorDAO.Cadastrar(v);
                    Console.WriteLine("Vendedor cadastrado!");
                }
                else Console.WriteLine("CPF já está cadastrado!");
            }
            else Console.WriteLine("CPF Inválido!");
        }
        public static void CadastrarProduto()
        {
            Produto p = new Produto();
            Produto existe = new Produto();
            Console.WriteLine("Informe o nome: ");
            p.Nome = Console.ReadLine();

            existe = ProdutoDAO.BuscaPorNome(p);
            if (existe == null)
            {
                Console.WriteLine("Informe o preço:");
                p.Preco = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Informe a quantidade:");
                p.Qtd = Convert.ToInt32(Console.ReadLine());
                ProdutoDAO.Cadastrar(p);
                Console.WriteLine("Produto cadastrado!");
            }
            else Console.WriteLine("Produto já está cadastrado!");
        }
    }
}
