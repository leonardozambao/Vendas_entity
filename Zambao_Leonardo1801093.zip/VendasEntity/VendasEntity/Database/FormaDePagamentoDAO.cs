﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Model;

namespace VendasEntity.Database
{
    class FormaDePagamentoDAO
    {
        private static Context ctx = SingletonContext.GetInstance();
        public static void Cadastrar(FormaDePagamento fp)
        {
            ctx.FormasDePagamento.Add(fp);
            ctx.SaveChanges();
        }
        public static List<FormaDePagamento> RetornarTodos()
        {
            return ctx.FormasDePagamento.ToList();
        }
        public static FormaDePagamento BuscaPorNome(FormaDePagamento fp)
        {
            return ctx.FormasDePagamento.FirstOrDefault(x => x.Nome.Equals(fp.Nome));
        }
    }
}
