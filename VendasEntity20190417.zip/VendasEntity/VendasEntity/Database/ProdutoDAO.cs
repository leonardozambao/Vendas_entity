﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Model;

namespace VendasEntity.Database
{
    class ProdutoDAO
    {
        private static Context ctx = SingletonContext.GetInstance();
        public static void Cadastrar(Produto p)
        {
            ctx.Produtos.Add(p);
            ctx.SaveChanges();
        }
        public static List<Produto> RetornarTodos()
        {
            // retorna todos os dados para uma lista
            return ctx.Produtos.ToList();
        }
        public static Produto BuscaPorNome(Produto p)
        {
            //retorna o primeiro valor encontrado
            return ctx.Produtos.FirstOrDefault(x => x.Nome.Equals(p.Nome));
        }
    }
}
