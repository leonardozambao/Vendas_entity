﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.Model
{
    /// <summary>
    /// Essa classe representa o banco de dados da aplicação e o EntityFramework
    /// </summary>
    class Context : DbContext
    {
        public Context() : base("DbCadastro") { } //renomear o banco 
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Vendedor> Vendedores { get; set; }
        public DbSet<Produto> Produtos { get; set; }
        public DbSet<Venda> Vendas { get; set; }
        public DbSet<FormaDePagamento> FormasDePagamento { get; set; }
        public DbSet<ItemForma> ItensForma { get; set; }
        public DbSet<ItemVenda> ItensVenda { get; set; }

        // console
        // install-package EntityFramework
        // uninstall-package EntityFramework
        // enable-migrations | just once
        // add-migration
        // update-database -verbose
        // add-migration CriarEstado; update-database -verbose
    }
}
