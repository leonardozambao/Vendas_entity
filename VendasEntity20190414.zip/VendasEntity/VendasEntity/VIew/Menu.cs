﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.VIew
{
    class Menu
    {
        public static void Imprimir()
        {
            Console.WriteLine("--------------------------");
            Console.WriteLine("- 1 - Cadastrar Cliente");
            Console.WriteLine("- 2 - Listar Clientes");
            Console.WriteLine("- 3 - Cadastrar Vendedor");
            Console.WriteLine("- 4 - Listar Vendedores");
            Console.WriteLine("- 5 - Cadastrar Produto");
            Console.WriteLine("- 6 - Listar Produtos");
            Console.WriteLine("- 0 - SAIR");
        }
        public static void Finalizar()
        {
            Console.WriteLine("Programa encerrado. Pressione uma tecla para finalizar.");
            Console.ReadKey();
        }

    }
}
