namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Primeira : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Clientes",
                c => new
                    {
                        ClienteID = c.Int(nullable: false, identity: true),
                        Cpf = c.String(),
                        Nome = c.String(),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ClienteID);
            
            CreateTable(
                "dbo.Produtos",
                c => new
                    {
                        ProdutoID = c.Int(nullable: false, identity: true),
                        Nome = c.String(),
                        Preco = c.Double(nullable: false),
                        Qtd = c.Int(nullable: false),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ProdutoID);
            
            CreateTable(
                "dbo.Vendedores",
                c => new
                    {
                        VendedorID = c.Int(nullable: false, identity: true),
                        Cpf = c.String(),
                        Nome = c.String(),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.VendedorID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Vendedores");
            DropTable("dbo.Produtos");
            DropTable("dbo.Clientes");
        }
    }
}
