﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Model;

namespace VendasEntity.Database
{
    class VendaDAO
    {
        private static Context ctx = SingletonContext.GetInstance();
        public static void Cadastrar(Venda v)
        {
            ctx.Vendas.Add(v);
            ctx.SaveChanges();
        }
        public static List<Venda> RetornarTodos()
        {
            return ctx.Vendas
            .Include("ItemForma")
            .Include("Vendedor")
            .Include("Cliente")
            .Include("ItensVenda.Produto").ToList();
        }
        public static List<Venda> RetornarVendasPorCpf(Cliente c)
        {
            return ctx.Vendas
            .Include("ItemForma")
            .Include("Vendedor")
            .Include("Cliente")
            .Include("ItensVenda.Produto")
            .Where(x => x.Cliente.Cpf.Equals(c.Cpf))
            .ToList();
        }
    }
}
