﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;
using VendasEntity.Util;

namespace VendasEntity.VIew
{
    class Alterar
    {
        public static void AlterarProduto()
        {
            Produto p = new Produto();
            Console.WriteLine("Informe o nome do produto que você deseja alterar: ");
            p.Nome = Console.ReadLine();
            p = ProdutoDAO.BuscaPorNome(p);
            if (p != null)
            {
                Console.WriteLine(p);
                String op;
                Boolean continuar = true;

                do
                {
                    Menu.MenuAlterarProduto();
                    op = Console.ReadLine();
                    switch (op)
                    {
                        case "1":
                            Console.WriteLine("informe o novo nome: ");
                            p.Nome = Console.ReadLine();
                            ControleProduto.Controle(p);
                            Console.WriteLine("Produto Alterado!");
                            break;
                        case "2":
                            Console.WriteLine("informe o novo preço: ");
                            p.Preco = Convert.ToDouble(Console.ReadLine());
                            ControleProduto.Controle(p);
                            Console.WriteLine("Produto Alterado!");
                            break;
                        case "3":
                            Console.WriteLine("informe o número em estoque: ");
                            p.Qtd = Convert.ToInt32(Console.ReadLine());
                            ControleProduto.Controle(p);
                            Console.WriteLine("Produto Alterado!");
                            break;
                        case "0":
                            continuar = false;
                            break;
                        default:
                            Console.WriteLine("OP Inválida!");
                            break;
                    }
                } while (continuar);

                
            }
            else Console.WriteLine("Nenhum produto encontrado!");
        }   
    }
}
