﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;
using VendasEntity.Util;

namespace VendasEntity.VIew
{
    class RegistraVenda
    {
        public static void Registra()
        {
            Venda venda = new Venda();
            Cliente c = new Cliente();
            Vendedor v = new Vendedor();
            double totalCompra = 0;
            double valorSomadoFormas = 0;
            Console.WriteLine("Informe o cpf do Cliente:");
            c.Cpf = Console.ReadLine();
            c = ClienteDAO.BuscaPorCpf(c);
            if (c != null)
            {
                venda.Cliente = c;
                Console.WriteLine("Informe o cpf do Vendedor:");
                v.Cpf = Console.ReadLine();
                v = VendedorDAO.BuscaPorCpf(v);
                if (v != null)
                {
                    venda.Vendedor = v;
                    String op;
                    do
                    {
                        Produto p = new Produto();
                        ItemVenda iv = new ItemVenda();
                        Console.WriteLine("\nInforme o nome do produto:");
                        p.Nome = Console.ReadLine();
                        p = ProdutoDAO.BuscaPorNome(p);
                        if (p != null)
                        {
                            if (p.Qtd > 0)
                            {
                                iv.Produto = p;
                                Console.WriteLine("estoque atual: " + p.Qtd);
                                Console.WriteLine("Informe a quantidade de itens: ");
                                iv.Quantidade = Convert.ToInt32(Console.ReadLine());
                                if (iv.Quantidade <= p.Qtd)
                                {
                                    iv.Preco = iv.Quantidade * p.Preco;
                                    venda.ItensVenda.Add(iv);
                                    p.Qtd = p.Qtd - iv.Quantidade;
                                    ControleProduto.Controle(p);
                                    Console.WriteLine("estoque atualizado: " + p.Qtd);
                                    totalCompra += iv.Preco;
                                }
                                else Console.WriteLine("Quanditade maior do que o permitido.\nEstoque atual: " + p.Qtd);
                            }
                            else Console.WriteLine("Infelizmente acabou o estoque deste produto :(");
                        }
                        else Console.WriteLine("Produto inexistente!");
                        Console.WriteLine("Deseja adicionar outro produto? S / N");
                        op = Console.ReadLine();

                    } while (op.ToUpper().Equals("S"));
                    do
                    {
                        FormaDePagamento fp = new FormaDePagamento();
                        ItemForma itemForma = new ItemForma();
                        itemForma.Venda = venda;
                        Console.WriteLine("Informe a forma de pagamento: ");
                        fp.Nome = Console.ReadLine();
                        fp = FormaDePagamentoDAO.BuscaPorNome(fp);
                        if (fp != null)
                        {
                            Console.WriteLine("Valor deste pagamento: (Valor Restante => " + (totalCompra - valorSomadoFormas).ToString("C2") + ")");
                            itemForma.Valor = Convert.ToDouble(Console.ReadLine());
                            valorSomadoFormas += itemForma.Valor;
                        }
                        else Console.WriteLine("forma de pagamento inexistente!");
                        if (valorSomadoFormas == totalCompra) break;
                        else if (valorSomadoFormas > totalCompra)
                        {
                            Console.WriteLine("Valor ultrapassou o valor total da compra!");
                            break;
                        }
                        else
                        {
                            Console.WriteLine("por favor, adicione mais uma forma de pagamento. Valor restante: " + (totalCompra - valorSomadoFormas).ToString("C2"));
                        }
                        Console.WriteLine("Deseja adicionar outra forma de pagamento? S / N");
                        op = Console.ReadLine();
                    } while (op.ToUpper().Equals("S"));
                    if (valorSomadoFormas == totalCompra)
                    {
                        venda.DataVenda = DateTime.Now;
                        VendaDAO.Cadastrar(venda);
                        Console.WriteLine("Venda cadastrada com sucesso!");
                    }
                    else Console.WriteLine("Valor incorreto de compra!");
                }
                else Console.WriteLine("Vendedor inexistente!");
            }
            else Console.WriteLine("Cliente inexistente!");
        }
    }
}
