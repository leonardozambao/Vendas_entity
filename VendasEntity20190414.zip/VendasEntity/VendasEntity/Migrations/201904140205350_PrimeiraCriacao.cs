namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class PrimeiraCriacao : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Clientes",
                c => new
                    {
                        ClienteID = c.Int(nullable: false, identity: true),
                        Cpf = c.String(),
                        Nome = c.String(),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ClienteID);
            
            CreateTable(
                "dbo.Vendedores",
                c => new
                    {
                        VendedorID = c.Int(nullable: false, identity: true),
                        Cpf = c.String(),
                        Nome = c.String(),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.VendedorID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Vendedores");
            DropTable("dbo.Clientes");
        }
    }
}
