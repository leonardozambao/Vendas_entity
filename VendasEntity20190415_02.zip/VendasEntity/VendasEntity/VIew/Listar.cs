﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;

namespace VendasEntity.VIew
{
    class Listar
    {
        // cliente
        public static void ListarCliente()
        {
            foreach (var item in ClienteDAO.RetornarTodos())
            {
                Console.WriteLine(item);
            }
        }
        public static void ListarClientePorCpf()
        {
            Cliente c = new Cliente();
            Console.WriteLine("Informe o CPF: ");
            c.Cpf = Console.ReadLine();
            c = ClienteDAO.BuscaPorCpf(c);
            if (c != null)
            {
                Console.WriteLine(c);
            }
            else Console.WriteLine("Cliente não encontrado!");
        }
        // vendedor
        public static void ListarVendedor()
        {
            foreach (var item in VendedorDAO.RetornarTodos())
            {
                Console.WriteLine(item);
            }
        }
        public static void ListarVendedorPorCpf()
        {
            Vendedor v = new Vendedor();
            Console.WriteLine("Informe o CPF: ");
            v.Cpf = Console.ReadLine();
            v = VendedorDAO.BuscaPorCpf(v);
            if (v != null)
            {
                Console.WriteLine(v);
            }
            else Console.WriteLine("Vendedor não encontrado!");
            
        }
        //produto
        public static void ListarProduto()
        {
            foreach (var item in ProdutoDAO.RetornarTodos())
            {
                Console.WriteLine(item);
            }
        }
        public static void ListarProdutoPorNome()
        {
            Produto p = new Produto();
            Console.WriteLine("Informe o nome:");
            p.Nome = Console.ReadLine();
            p = ProdutoDAO.BuscaPorNome(p);
            if (p != null)
            {
                Console.WriteLine(p);
            }
            else Console.WriteLine("Produto inexistente!");
        }
    }
}
