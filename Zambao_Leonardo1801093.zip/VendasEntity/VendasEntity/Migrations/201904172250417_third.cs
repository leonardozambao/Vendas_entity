namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class third : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ItensForma",
                c => new
                    {
                        ItemFormaID = c.Int(nullable: false, identity: true),
                        Valor = c.Double(nullable: false),
                        Venda_VendaID = c.Int(),
                    })
                .PrimaryKey(t => t.ItemFormaID)
                .ForeignKey("dbo.Vendas", t => t.Venda_VendaID)
                .Index(t => t.Venda_VendaID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ItensForma", "Venda_VendaID", "dbo.Vendas");
            DropIndex("dbo.ItensForma", new[] { "Venda_VendaID" });
            DropTable("dbo.ItensForma");
        }
    }
}
