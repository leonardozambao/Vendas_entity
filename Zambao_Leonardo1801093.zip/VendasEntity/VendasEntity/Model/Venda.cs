﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.Model
{
    [Table("Vendas")]
    class Venda
    {
        public Venda()
        {
            CriadoEm = DateTime.Now;
            ItensVenda = new List<ItemVenda>();
            Cliente = new Cliente();
            Produto = new Produto();
            FormaDePagamento = new List<FormaDePagamento>();
            ItemForma = new List<ItemForma>();
            Vendedor = new Vendedor();
        }
        [Key]
        public int VendaID { get; set; }
        public List<ItemVenda> ItensVenda { get; set; }
        public Cliente Cliente { get; set; }
        public Vendedor Vendedor { get; set; }
        public Produto Produto { get; set; }
        public List<FormaDePagamento> FormaDePagamento { get; set; }
        public List<ItemForma> ItemForma { get; set; }
        public DateTime CriadoEm { get; set; }
        public DateTime DataVenda { get; set; }
    }
}
