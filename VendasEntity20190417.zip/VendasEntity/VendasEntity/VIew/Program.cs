﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.VIew;

namespace VendasEntity.View
{
    class Program
    {
        static void Main(string[] args)
        {
            Boolean continuar = true;
            string op;
            do
            {
                Menu.Imprimir();
                op = Console.ReadLine();
                Console.Clear();
                switch (op)
                {
                    case "0":
                        continuar = false;
                        break;
                    case "1":
                        Cadastrar.CadastrarCliente();
                        break;
                    case "2":
                        Listar.ListarCliente();
                        break;
                    case "3":
                        Cadastrar.CadastrarVendedor();
                        break;
                    case "4":
                        Listar.ListarVendedor();
                        break;
                    case "5":
                        Cadastrar.CadastrarProduto();
                        break;
                    case "6":
                        Listar.ListarProduto();
                        break;
                    case "7":
                        RegistraVenda.Registra();
                        break;
                    case "8":
                        Listar.ListarVendas();
                        break;
                    case "9":
                        Listar.ListarVendaPorCpf();
                        break;
                    case "10":
                        Alterar.AlterarProduto();
                        break;
                    default:
                        Console.WriteLine("OP Inválida!");
                        break;
                }
            } while (continuar);
            Menu.Finalizar();
        }
    }
}
