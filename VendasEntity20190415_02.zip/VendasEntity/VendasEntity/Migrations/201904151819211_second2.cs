namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class second2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.ItensVenda", "Produto_ProdutoID", c => c.Int());
            CreateIndex("dbo.ItensVenda", "Produto_ProdutoID");
            AddForeignKey("dbo.ItensVenda", "Produto_ProdutoID", "dbo.Produtos", "ProdutoID");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.ItensVenda", "Produto_ProdutoID", "dbo.Produtos");
            DropIndex("dbo.ItensVenda", new[] { "Produto_ProdutoID" });
            DropColumn("dbo.ItensVenda", "Produto_ProdutoID");
        }
    }
}
