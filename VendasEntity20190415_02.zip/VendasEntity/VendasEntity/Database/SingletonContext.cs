﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Model;

namespace VendasEntity.Database
{
    class SingletonContext
    {
        private SingletonContext() { }
        private static Context context;
        public static Context GetInstance()
        {
            if (context == null) context = new Context();
            return context;
        }
    }
}
