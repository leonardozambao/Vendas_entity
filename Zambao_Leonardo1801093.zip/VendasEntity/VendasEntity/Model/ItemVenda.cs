﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.Model
{
    [Table("ItensVenda")]
    class ItemVenda
    {
        public ItemVenda()
        {
            Produto = new Produto();
            CriadoEm = DateTime.Now;
        }
        [Key]
        public int ItemVendaID { get; set; }
        public int Quantidade { get; set; }
        public double Preco { get; set; }
        public Produto Produto { get; set; }
        public DateTime CriadoEm { get; set; }
    }
}
