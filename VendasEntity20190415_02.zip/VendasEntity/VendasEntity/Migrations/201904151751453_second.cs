namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class second : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ItensVenda",
                c => new
                    {
                        ItemVendaID = c.Int(nullable: false, identity: true),
                        Quantidade = c.Int(nullable: false),
                        Preco = c.Double(nullable: false),
                        CriadoEm = c.DateTime(nullable: false),
                        Venda_VendaID = c.Int(),
                    })
                .PrimaryKey(t => t.ItemVendaID)
                .ForeignKey("dbo.Vendas", t => t.Venda_VendaID)
                .Index(t => t.Venda_VendaID);
            
            CreateTable(
                "dbo.Vendas",
                c => new
                    {
                        VendaID = c.Int(nullable: false, identity: true),
                        CriadoEm = c.DateTime(nullable: false),
                        DataVenda = c.DateTime(nullable: false),
                        Cliente_ClienteID = c.Int(),
                        Vendedor_VendedorID = c.Int(),
                    })
                .PrimaryKey(t => t.VendaID)
                .ForeignKey("dbo.Clientes", t => t.Cliente_ClienteID)
                .ForeignKey("dbo.Vendedores", t => t.Vendedor_VendedorID)
                .Index(t => t.Cliente_ClienteID)
                .Index(t => t.Vendedor_VendedorID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Vendas", "Vendedor_VendedorID", "dbo.Vendedores");
            DropForeignKey("dbo.ItensVenda", "Venda_VendaID", "dbo.Vendas");
            DropForeignKey("dbo.Vendas", "Cliente_ClienteID", "dbo.Clientes");
            DropIndex("dbo.Vendas", new[] { "Vendedor_VendedorID" });
            DropIndex("dbo.Vendas", new[] { "Cliente_ClienteID" });
            DropIndex("dbo.ItensVenda", new[] { "Venda_VendaID" });
            DropTable("dbo.Vendas");
            DropTable("dbo.ItensVenda");
        }
    }
}
