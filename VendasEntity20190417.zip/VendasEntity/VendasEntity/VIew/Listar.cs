﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;

namespace VendasEntity.VIew
{
    class Listar
    {
        // cliente
        public static void ListarCliente()
        {
            int cont = 0;
            foreach (var item in ClienteDAO.RetornarTodos())
            {
                Console.WriteLine(item);
                cont++;
            }
            if (cont == 0) Console.WriteLine("Nenhum cliente cadastrado!");
        }
        public static void ListarClientePorCpf()
        {
            Cliente c = new Cliente();
            Console.WriteLine("Informe o CPF: ");
            c.Cpf = Console.ReadLine();
            c = ClienteDAO.BuscaPorCpf(c);
            if (c != null)
            {
                Console.WriteLine(c);
            }
            else Console.WriteLine("Cliente não encontrado!");
        }
        // vendedor
        public static void ListarVendedor()
        {
            int cont = 0;
            foreach (var item in VendedorDAO.RetornarTodos())
            {
                Console.WriteLine(item);
                cont++;
            }
            if (cont == 0) Console.WriteLine("Nenhum cliente cadastrado!");
        }
        public static void ListarVendedorPorCpf()
        {
            Vendedor v = new Vendedor();
            Console.WriteLine("Informe o CPF: ");
            v.Cpf = Console.ReadLine();
            v = VendedorDAO.BuscaPorCpf(v);
            if (v != null)
            {
                Console.WriteLine(v);
            }
            else Console.WriteLine("Vendedor não encontrado!");
            
        }
        // produto
        public static void ListarProduto()
        {
            int cont = 0;
            foreach (var item in ProdutoDAO.RetornarTodos())
            {
                if (item.Nome != null) Console.WriteLine(item);
                cont++;
            }
            if (cont == 0) Console.WriteLine("Nenhum cliente cadastrado!");
        }
        public static void ListarProdutoPorNome()
        {
            Produto p = new Produto();
            Console.WriteLine("Informe o nome:");
            p.Nome = Console.ReadLine();
            p = ProdutoDAO.BuscaPorNome(p);
            if (p != null)
            {
                Console.WriteLine(p);
            }
            else Console.WriteLine("Produto inexistente!");
        }
        // vendas
        public static void ListarVendas()
        {
            int cont = 0;
            foreach (var item in VendaDAO.RetornarTodos())
            {
                Console.WriteLine("Nome Cliente => " + item.Cliente.Nome);
                Console.WriteLine("Nome Vendedor => " + item.Vendedor.Nome);
                Console.WriteLine("Data => " + item.DataVenda);
                Console.WriteLine("----- PRODUTOS -----");
                double total = 0;
                foreach (var prod in item.ItensVenda)
                {
                    Console.WriteLine("\tNome => " + prod.Produto.Nome);
                    Console.WriteLine("\tValor Unitário => " + prod.Produto.Preco);
                    Console.WriteLine("\tQuantidade => " + prod.Quantidade);
                    Console.WriteLine("\tSubtotal => " + prod.Quantidade * prod.Produto.Preco +"\n");
                    total = total + prod.Quantidade * prod.Produto.Preco;
                }
                Console.WriteLine("Total da Compra => " + total.ToString("C2"));
                Console.WriteLine("--------------------");

                cont++;
            }
            if (cont == 0) Console.WriteLine("Nenhuma venda cadastrado!");
        }
        public static void ListarVendaPorCpf()
        {
            int cont = 0;
            Cliente c = new Cliente();
            Console.WriteLine("Informe o CPF do cliente: ");
            c.Cpf = Console.ReadLine();
            foreach (var item in VendaDAO.RetornarVendasPorCpf(c))
            {
                Console.WriteLine("\nNome Cliente => " + item.Cliente.Nome);
                Console.WriteLine("Nome Vendedor => " + item.Vendedor.Nome);
                Console.WriteLine("Data => " + item.DataVenda); Console.WriteLine("----- PRODUTOS -----");
                double total = 0;
                foreach (var prod in item.ItensVenda)
                {
                    Console.WriteLine("\tNome => " + prod.Produto.Nome);
                    Console.WriteLine("\tValor Unitário => " + prod.Produto.Preco);
                    Console.WriteLine("\tQuantidade => " + prod.Quantidade);
                    Console.WriteLine("\tSubtotal => " + prod.Quantidade * prod.Produto.Preco + "\n");
                    total = total + prod.Quantidade * prod.Produto.Preco;
                }
                Console.WriteLine("Total da Compra => " + total.ToString("C2"));
                Console.WriteLine("--------------------");
                cont++;
            }

            if (cont == 0) Console.WriteLine("Nenhuma venda cadastrada neste CPF!");
        }

    }
}
