namespace VendasEntity.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CriaBanco : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Clientes",
                c => new
                    {
                        ClienteID = c.Int(nullable: false, identity: true),
                        Cpf = c.String(),
                        Nome = c.String(),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ClienteID);
            
            CreateTable(
                "dbo.Vendas",
                c => new
                    {
                        VendaID = c.Int(nullable: false, identity: true),
                        CriadoEm = c.DateTime(nullable: false),
                        DataVenda = c.DateTime(nullable: false),
                        Cliente_ClienteID = c.Int(),
                        Produto_ProdutoID = c.Int(),
                        Vendedor_VendedorID = c.Int(),
                    })
                .PrimaryKey(t => t.VendaID)
                .ForeignKey("dbo.Clientes", t => t.Cliente_ClienteID)
                .ForeignKey("dbo.Produtos", t => t.Produto_ProdutoID)
                .ForeignKey("dbo.Vendedores", t => t.Vendedor_VendedorID)
                .Index(t => t.Cliente_ClienteID)
                .Index(t => t.Produto_ProdutoID)
                .Index(t => t.Vendedor_VendedorID);
            
            CreateTable(
                "dbo.ItensVenda",
                c => new
                    {
                        ItemVendaID = c.Int(nullable: false, identity: true),
                        Quantidade = c.Int(nullable: false),
                        Preco = c.Double(nullable: false),
                        CriadoEm = c.DateTime(nullable: false),
                        Produto_ProdutoID = c.Int(),
                        Venda_VendaID = c.Int(),
                    })
                .PrimaryKey(t => t.ItemVendaID)
                .ForeignKey("dbo.Produtos", t => t.Produto_ProdutoID)
                .ForeignKey("dbo.Vendas", t => t.Venda_VendaID)
                .Index(t => t.Produto_ProdutoID)
                .Index(t => t.Venda_VendaID);
            
            CreateTable(
                "dbo.Produtos",
                c => new
                    {
                        ProdutoID = c.Int(nullable: false, identity: true),
                        Nome = c.String(),
                        Preco = c.Double(nullable: false),
                        Qtd = c.Int(nullable: false),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.ProdutoID);
            
            CreateTable(
                "dbo.Vendedores",
                c => new
                    {
                        VendedorID = c.Int(nullable: false, identity: true),
                        Cpf = c.String(),
                        Nome = c.String(),
                        HoraCadastro = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.VendedorID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Vendas", "Vendedor_VendedorID", "dbo.Vendedores");
            DropForeignKey("dbo.Vendas", "Produto_ProdutoID", "dbo.Produtos");
            DropForeignKey("dbo.ItensVenda", "Venda_VendaID", "dbo.Vendas");
            DropForeignKey("dbo.ItensVenda", "Produto_ProdutoID", "dbo.Produtos");
            DropForeignKey("dbo.Vendas", "Cliente_ClienteID", "dbo.Clientes");
            DropIndex("dbo.ItensVenda", new[] { "Venda_VendaID" });
            DropIndex("dbo.ItensVenda", new[] { "Produto_ProdutoID" });
            DropIndex("dbo.Vendas", new[] { "Vendedor_VendedorID" });
            DropIndex("dbo.Vendas", new[] { "Produto_ProdutoID" });
            DropIndex("dbo.Vendas", new[] { "Cliente_ClienteID" });
            DropTable("dbo.Vendedores");
            DropTable("dbo.Produtos");
            DropTable("dbo.ItensVenda");
            DropTable("dbo.Vendas");
            DropTable("dbo.Clientes");
        }
    }
}
