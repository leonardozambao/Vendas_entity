﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;

namespace VendasEntity.Util
{
    class ControleProduto
    {
        // método para validar quantidad de estoque, e atualizar após confirmação de compra
        private static Context ctx = SingletonContext.GetInstance();
        public static void Controle(Produto p)
        {
            ctx.Entry(p).State = System.Data.Entity.EntityState.Modified;
            ctx.SaveChanges();
        }
    }
}
