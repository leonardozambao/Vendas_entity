﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendasEntity.VIew
{
    class Menu
    {
        public static void Imprimir()
        {
            Console.WriteLine("--------------------------");
            Console.WriteLine("- 1 - Cadastrar Cliente");
            Console.WriteLine("- 2 - Listar Clientes");
            Console.WriteLine("- 3 - Cadastrar Vendedor");
            Console.WriteLine("- 4 - Listar Vendedores");
            Console.WriteLine("- 5 - Cadastrar Produto");
            Console.WriteLine("- 6 - Listar Produtos");
            Console.WriteLine("- 7 - Registrar Venda");
            Console.WriteLine("- 8 - Listar Vendas");
            Console.WriteLine("- 9 - Listar Vendas por CPF de cliente");
            Console.WriteLine("- 10 - Cadastrar forma de pagamento");
            Console.WriteLine("- 11 - Listar forma de pagamento");
            Console.WriteLine("- 12 - Alterar Produto/Estoque");
            Console.WriteLine("- 0 - SAIR");
        }
        public static void MenuAlterarProduto()
        {
            Console.WriteLine("O que você deseja alterar?");
            Console.WriteLine("--------------------------");
            Console.WriteLine("- 1 - Alterar Nome");
            Console.WriteLine("- 2 - Alterar Preço");
            Console.WriteLine("- 3 - Alterar quantidade em estoque");
            Console.WriteLine("- 0 - SAIR");
        }
        public static void Finalizar()
        {
            Console.WriteLine("Programa encerrado. Pressione uma tecla para finalizar.");
            Console.ReadKey();
        }

    }
}
