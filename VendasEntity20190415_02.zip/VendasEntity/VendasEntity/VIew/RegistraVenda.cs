﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Database;
using VendasEntity.Model;

namespace VendasEntity.VIew
{
    class RegistraVenda
    {
        public static void Registra()
        {
            Venda venda = new Venda();
            Produto p = new Produto();
            ItemVenda iv = new ItemVenda();
            Cliente c = new Cliente();
            Vendedor v = new Vendedor();
            Console.WriteLine("Informe o cpf do Cliente:");
            c.Cpf = Console.ReadLine();
            c = ClienteDAO.BuscaPorCpf(c);
            if (c != null)
            {
                venda.Cliente = c;
                Console.WriteLine("Informe o cpf do Vendedor:");
                v.Cpf = Console.ReadLine();
                v = VendedorDAO.BuscaPorCpf(v);
                if (v != null)
                {
                    venda.Vendedor = v;
                    Console.WriteLine("Informe o nome do produto:");
                    p.Nome = Console.ReadLine();
                    p = ProdutoDAO.BuscaPorNome(p);
                    if (p != null)
                    {
                        iv.Produto = p;
                        Console.WriteLine("Informe a quantidade de itens: ");
                        iv.Quantidade = Convert.ToInt32(Console.ReadLine());
                        venda.DataVenda = DateTime.Now;
                        venda.ItensVenda.Add(iv);
                        VendaDAO.Cadastrar(venda);
                        Console.WriteLine("Venda cadastrada com sucesso!");
                    }
                    else Console.WriteLine("Produto inexistente!");
                }
                else Console.WriteLine("Vendedor inexistente!");
            }
            else Console.WriteLine("Cliente inexistente!");
        }
    }
}
