﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendasEntity.Model;

namespace VendasEntity.Database
{
    class ClienteDAO
    {
        private static Context ctx = SingletonContext.GetInstance();
        public static void Cadastrar (Cliente c)
        {
            ctx.Clientes.Add(c);
            ctx.SaveChanges();
        }
        public static List<Cliente> RetornarTodos()
        {
            // retorna todos os dados para uma lista
            return ctx.Clientes.ToList();
        }
        public static Cliente BuscaPorCpf(Cliente c)
        {   
            //retorna o primeiro valor encontrado
            return ctx.Clientes.FirstOrDefault(x => x.Cpf.Equals(c.Cpf)); 
        }
    }
}
